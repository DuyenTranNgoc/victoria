function send(){
    var arr= document.getElementsByTagName('input');
    var fullname= arr [0].value;
    var password= arr[1].value;
    if (fullname == "" || password == ""){
        alert ('Pls fill all fields');
        return;
    }
    var choice = confirm('Comfrim your infomation\n'+ 'Fullname:' + fullname+ "\n"+ 'Age: ' +age+ "\n"+  'Phone: '  +phone+ "\n"+'Gender: ' +gender +"\n")
    if ( choice ==1 ){
        alert('Information sent')
    
    }
}