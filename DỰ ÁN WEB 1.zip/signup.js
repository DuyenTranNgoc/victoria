function send(){
    var arr= document.getElementsByTagName('input');
    var fullname= arr [0].value;
    var age= arr[1].value;
    var phone= arr[2].value;
    var gender= ""

    if (arr[3].checked){
        gender= 'male';
    } else {
        gender ='female';
    }
    if (fullname == "" || age == "" || phone == ""){
        alert ('Pls fill all fields');
        return;
    }
    if (isNaN(age)){
        alert ('Age must be a number');
        return;
    }
    if (isNaN(phone)){
        alert ('Phone must be a number');
        return;
    }
    var choice = confirm('Comfrim your infomation\n'+ 'Fullname:' + fullname+ "\n"+ 'Age: ' +age+ "\n"+  'Phone: '  +phone+ "\n"+'Gender: ' +gender +"\n")
    if ( choice ==1 ){
        alert('Information sent')
    
    }
}