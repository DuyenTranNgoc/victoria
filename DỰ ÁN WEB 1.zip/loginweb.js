let demo=false
let demo1=false
let demo2=false
let demo3=false
let demo4=false
let demo5=false
let demo6=false
let demo7=false
let demo8=false

document.getElementById("demo").ondblclick = function() {myFunction0()};

function myFunction0() {
  if (demo){
    demo=false;
    document.getElementById("demo").innerHTML = "❤️";
  }
  else{
    demo=true;
    document.getElementById("demo").innerHTML = "🤍";
  }
 
}

document.getElementById("demo1").ondblclick = function() {myFunction1()};

function myFunction1() {
  if (demo1){
    demo1=false;
    document.getElementById("demo1").innerHTML = "❤️";
  }
  else{
    demo1=true;
    document.getElementById("demo1").innerHTML = "🤍";
  }
}

document.getElementById("demo2").ondblclick = function() {myFunction2()};

function myFunction2() {
  if (demo2){
    demo2=false;
    document.getElementById("demo2").innerHTML = "❤️";
  }
  else{
    demo2=true;
    document.getElementById("demo2").innerHTML = "🤍";
  }
}

document.getElementById("demo3").ondblclick = function() {myFunction3()};

function myFunction3() {
  if (demo3){
    demo3=false;
    document.getElementById("demo3").innerHTML = "❤️";
  }
  else{
    demo3=true;
    document.getElementById("demo3").innerHTML = "🤍";
  }
}

document.getElementById("demo4").ondblclick = function() {myFunction4()};

function myFunction4() {
  if (demo4){
    demo4=false;
    document.getElementById("demo4").innerHTML = "❤️";
  }
  else{
    demo4=true;
    document.getElementById("demo4").innerHTML = "🤍";
  }
}

document.getElementById("demo5").ondblclick = function() {myFunction5()};

function myFunction5() {
  if (demo5){
    demo5=false;
    document.getElementById("demo5").innerHTML = "❤️";
  }
  else{
    demo5=true;
    document.getElementById("demo5").innerHTML = "🤍";
  }
}

document.getElementById("demo6").ondblclick = function() {myFunction6()};

function myFunction6() {
  if (demo6){
    demo6=false;
    document.getElementById("demo6").innerHTML = "❤️";
  }
  else{
    demo6=true;
    document.getElementById("demo6").innerHTML = "🤍";
  }
}

document.getElementById("demo7").ondblclick = function() {myFunction7()};

function myFunction7() {
  if (demo7){
    demo7=false;
    document.getElementById("demo7").innerHTML = "❤️";
  }
  else{
    demo7=true;
    document.getElementById("demo7").innerHTML = "🤍";
  }
}

document.getElementById("demo8").ondblclick = function() {myFunction8()};

function myFunction8() {
  if (demo8){
    demo8=false;
    document.getElementById("demo8").innerHTML = "❤️";
  }
  else{
    demo8=true;
    document.getElementById("demo8").innerHTML = "🤍";
  }
}

